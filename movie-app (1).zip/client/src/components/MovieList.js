import React, { useEffect, useState } from 'react';
import axios from 'axios';
import './MovieList.css';
import { Link } from 'react-router-dom';

function MovieList() {
  const [movies, setMovies] = useState([]);

  useEffect(() => {
    axios.get('/api/movies')
      .then(res => setMovies(res.data))
      .catch(err => console.log(err));
  }, []);

  return (
    <div className="movie-grid">
      {movies.map(movie => (
        <Link key={movie.id} to={`/movies/${movie.id}`} className="movie-card">
          <h3>{movie.title}</h3>
          <p><em>{movie.tagline}</em></p>
          <p>Rating: {movie.vote_average}/10</p>
        </Link>
      ))}
    </div>
  );
}

export default MovieList;