import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useParams, Link } from 'react-router-dom';

function MovieDetail() {
  const { id } = useParams();
  const [movie, setMovie] = useState(null);

  useEffect(() => {
    axios.get(`/api/movies/${id}`)
      .then(res => setMovie(res.data))
      .catch(err => console.log(err));
  }, [id]);

  if (!movie) return <div>Loading...</div>;

  const localizedDate = new Date(movie.release_date).toLocaleDateString();
  const runtime = `${movie.runtime} minutes`;

  return (
    <div style={{ padding: '20px' }}>
      <h1>{movie.title}</h1>
      <h2><em>{movie.tagline}</em></h2>
      <p><strong>Release Date:</strong> {localizedDate}</p>
      <p><strong>Runtime:</strong> {runtime}</p>
      <p><strong>Overview:</strong> {movie.overview}</p>
      <p><strong>Genres:</strong> {movie.genres}</p>
      <p><strong>Rating:</strong> {movie.vote_average}/10</p>
      <p><strong>Budget:</strong> ${movie.budget}</p>
      <Link to="/">← Back to list</Link>
    </div>
  );
}

export default MovieDetail;