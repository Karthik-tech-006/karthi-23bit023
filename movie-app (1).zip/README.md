# Movie App - Fullstack (React + Express)

## 🚀 How to Run

### Backend Setup
```bash
cd server
npm install
node index.js
```

### Frontend Setup
```bash
cd client
npm install
npm start
```

- Visit the app at `http://localhost:3000`
- The backend API is on `http://localhost:3001`