const express = require('express');
const fs = require('fs');
const cors = require('cors');
const app = express();
const PORT = process.env.PORT || 3001;

app.use(cors());

let movies = [];
fs.readFile('./server/movies_metadata.json', 'utf8', (err, data) => {
  if (err) throw err;
  movies = JSON.parse(data);
});

app.get('/api/movies', (req, res) => {
  const simplified = movies.map(({ id, title, tagline, vote_average }) => ({
    id, title, tagline, vote_average
  }));
  res.json(simplified);
});

app.get('/api/movies/:id', (req, res) => {
  const movie = movies.find(m => m.id === req.params.id);
  if (!movie) return res.status(404).json({ message: 'Movie not found' });
  res.json(movie);
});

app.listen(PORT, () => console.log(`Server running on port ${PORT}`));